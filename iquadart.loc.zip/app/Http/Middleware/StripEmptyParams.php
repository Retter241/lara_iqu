<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;

class StripEmptyParams
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure(\Illuminate\Http\Request): (\Illuminate\Http\Response|\Illuminate\Http\RedirectResponse)  $next
     * @return \Illuminate\Http\Response|\Illuminate\Http\RedirectResponse
     */
    public function handle(Request $request, Closure $next)
    {
           $query = request()->query();
            $querycount = count($query);
            foreach ($query as $key => $value) {
               
                if ($value == '' || $value == 0 || $value == 10000) {
                    unset($query[$key]);
                }
                if(is_array($value)){
                    $string_value = implode(',',$value);
                    $query[$key] = $string_value;
                }
            }

            if ($querycount > count($query)) {
                $path = url()->current() . (!empty($query) ? '/?' . http_build_query($query) : '');
                return redirect()->to($path);
            }
            return $next($request);
    }
}
